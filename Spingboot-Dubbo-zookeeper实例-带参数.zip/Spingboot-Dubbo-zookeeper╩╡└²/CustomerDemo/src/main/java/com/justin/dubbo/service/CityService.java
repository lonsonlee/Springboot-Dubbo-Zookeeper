package com.justin.dubbo.service;

import com.justin.dubbo.domain.City;

public interface CityService {
    public City findCityByName(String cityname);
}
