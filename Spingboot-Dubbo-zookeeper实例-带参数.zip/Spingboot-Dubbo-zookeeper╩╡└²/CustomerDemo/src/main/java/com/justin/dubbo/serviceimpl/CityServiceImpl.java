package com.justin.dubbo.serviceimpl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.justin.dubbo.MyCityService.MyServiceCity;
import com.justin.dubbo.domain.City;
import com.justin.dubbo.service.CityService;
import org.springframework.stereotype.Component;

@Component
public class CityServiceImpl implements MyServiceCity
{
    @Reference(version = "1.0.0")
    private CityService cityService;

    @Override
    public void printCity(String cityName) {
//        String cityName="铁岭";
        City city=cityService.findCityByName(cityName);
        System.out.println(city.toString());
    }
}
