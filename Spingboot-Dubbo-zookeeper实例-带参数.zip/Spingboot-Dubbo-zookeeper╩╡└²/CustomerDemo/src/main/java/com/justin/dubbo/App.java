package com.justin.dubbo;

import com.justin.dubbo.MyCityService.MyServiceCity;
import com.justin.dubbo.serviceimpl.CityServiceImpl;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

/**
 * Hello world!
 *
 */
@SpringBootApplication
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );

        ConfigurableApplicationContext run=  SpringApplication.run(App.class,args);
        MyServiceCity cityService = run.getBean(CityServiceImpl.class);
        cityService.printCity("北京");
        cityService.printCity("太原");
        cityService.printCity("天津");
        cityService.printCity("济南");
    }
}
