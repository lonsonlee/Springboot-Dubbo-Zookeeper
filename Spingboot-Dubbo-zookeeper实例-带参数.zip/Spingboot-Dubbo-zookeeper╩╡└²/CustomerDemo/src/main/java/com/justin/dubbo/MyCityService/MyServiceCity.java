package com.justin.dubbo.MyCityService;

public interface MyServiceCity {

    public void printCity(String cityName);

}
