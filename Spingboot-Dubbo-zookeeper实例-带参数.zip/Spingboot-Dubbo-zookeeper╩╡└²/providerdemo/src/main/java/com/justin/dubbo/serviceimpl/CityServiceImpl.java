package com.justin.dubbo.serviceimpl;

import com.justin.dubbo.domain.City;
import com.justin.dubbo.service.CityService;

import com.alibaba.dubbo.config.annotation.Service;

@Service(version = "1.0.0")
public class CityServiceImpl implements CityService {
    public City findCityByName(String cityname) {
        return new City(1L,2L,cityname,"不是我的故乡");
    }
}
